

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Productos')); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                    <a href="/regProductos">Productos.</a>
                    <hr>
                    <div class="table">
                    	<table>
                    		<thead class="thead-dark">
							    <tr>
							      <th scope="col">Nombre</th>
							      <th scope="col">Descripción</th>
							      <th scope="colspan-2">Acciones</th>
							    </tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($p->nombre); ?></td>
										<td><?php echo e($p->descripcion); ?></td>
										<td><a href="/regProductos/<?php echo e($p->id); ?>/edit"><button class="btn btn-success">Edit</button></a></td>
										<td>
											<form method="POST" action="/regProductos/<?php echo e($p->id); ?>">
												<?php echo method_field('DELETE'); ?>
												<?php echo csrf_field(); ?>
												<a href="/regProductos/<?php echo e($p->id); ?>"><button class="btn btn-danger">Eliminar</button></a>
											</form> 
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<?php echo e($productos->onEachSide(5)->links()); ?>	
                    	</table>
                    </div>		
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\colemanmx\resources\views/IntProductos/index.blade.php ENDPATH**/ ?>